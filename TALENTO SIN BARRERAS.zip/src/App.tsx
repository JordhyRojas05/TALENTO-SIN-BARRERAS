import { useState } from "react";
import { LandingPage } from "./components/LandingPage";
import { RegistrationPage } from "./components/RegistrationPage";
import { LoginPage } from "./components/LoginPage";
import { Dashboard } from "./components/Dashboard";
import { UserProfile } from "./components/UserProfile";
import { Toaster } from "./components/ui/sonner";

type Page = 'landing' | 'register' | 'login' | 'dashboard' | 'profile';
type UserRole = 'postulante' | 'organismo' | 'tutor' | null;

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [userName, setUserName] = useState<string>("");

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const handleLogin = (role: UserRole, name: string) => {
    setUserRole(role);
    setUserName(name);
    setCurrentPage('dashboard');
  };

  return (
    <>
      {currentPage === 'landing' && <LandingPage onNavigate={handleNavigate} />}
      {currentPage === 'register' && <RegistrationPage onNavigate={handleNavigate} onRegister={handleLogin} />}
      {currentPage === 'login' && <LoginPage onNavigate={handleNavigate} onLogin={handleLogin} />}
      {currentPage === 'dashboard' && <Dashboard onNavigate={handleNavigate} userRole={userRole} userName={userName} />}
      {currentPage === 'profile' && <UserProfile onNavigate={handleNavigate} />}
      <Toaster position="top-right" />
    </>
  );
}